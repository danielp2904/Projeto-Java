-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29-Out-2022 às 20:36
-- Versão do servidor: 10.4.18-MariaDB
-- versão do PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `paintball`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cartao`
--

CREATE TABLE `cartao` (
  `idcartao` int(11) NOT NULL,
  `numero` varchar(45) NOT NULL,
  `data_validade` date NOT NULL,
  `nome_pessoa` text NOT NULL,
  `tipo_conta` text NOT NULL,
  `bandeira` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `dinheiro`
--

CREATE TABLE `dinheiro` (
  `id_dinheiro` int(11) NOT NULL,
  `especie` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `forma_pagamento`
--

CREATE TABLE `forma_pagamento` (
  `idforma_pagamento` int(11) NOT NULL,
  `cartao_idcartao` int(11) NOT NULL,
  `pix_id_chave_pix` text NOT NULL,
  `dinheiro_id_dinheiro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `nome` text NOT NULL,
  `idade` date NOT NULL,
  `telefone` int(11) NOT NULL,
  `email` text NOT NULL,
  `funcao` text NOT NULL,
  `expediente` text NOT NULL,
  `salario` char(10) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  `cpf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ingresso`
--

CREATE TABLE `ingresso` (
  `nome` text NOT NULL,
  `cpf` int(11) NOT NULL,
  `duracao_tempo` text NOT NULL,
  `dia_semana` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `jogador`
--

CREATE TABLE `jogador` (
  `cpf` int(11) NOT NULL,
  `nome` text NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` int(11) NOT NULL,
  `senha` text NOT NULL,
  `id_jogador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `jogador`
--

INSERT INTO `jogador` (`cpf`, `nome`, `data_nascimento`, `telefone`, `senha`, `id_jogador`) VALUES
(33355599, 'João', '2000-02-20', 2255881, 'paintbal01', 1),
(326547889, 'Isadora', '2004-12-01', 2147483647, 'isasora', 12);

-- --------------------------------------------------------

--
-- Estrutura da tabela `loja`
--

CREATE TABLE `loja` (
  `id_loja` int(14) NOT NULL,
  `ingresso` text NOT NULL,
  `calca_camuflada` text NOT NULL,
  `colete` text NOT NULL,
  `armamento` text NOT NULL,
  `tinta` text NOT NULL,
  `capacete` text NOT NULL,
  `oculos` text NOT NULL,
  `bota` char(2) NOT NULL,
  `camiseta_camuflada` text NOT NULL,
  `mascara` text NOT NULL,
  `pescoceira` text NOT NULL,
  `luva` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pix`
--

CREATE TABLE `pix` (
  `id_chave_pix` int(11) NOT NULL,
  `chave` text NOT NULL,
  `qrcode` binary(1) NOT NULL,
  `comprovante` binary(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `valor`
--

CREATE TABLE `valor` (
  `id_valor` int(11) NOT NULL,
  `valor` double NOT NULL,
  `pag_idforma_pagamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda`
--

CREATE TABLE `venda` (
  `id_venda` int(11) NOT NULL,
  `data_venda` date NOT NULL,
  `valor_id_valor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cartao`
--
ALTER TABLE `cartao`
  ADD PRIMARY KEY (`idcartao`);

--
-- Índices para tabela `dinheiro`
--
ALTER TABLE `dinheiro`
  ADD PRIMARY KEY (`id_dinheiro`);

--
-- Índices para tabela `forma_pagamento`
--
ALTER TABLE `forma_pagamento`
  ADD PRIMARY KEY (`idforma_pagamento`);

--
-- Índices para tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id_funcionario`);

--
-- Índices para tabela `ingresso`
--
ALTER TABLE `ingresso`
  ADD PRIMARY KEY (`cpf`);

--
-- Índices para tabela `jogador`
--
ALTER TABLE `jogador`
  ADD PRIMARY KEY (`id_jogador`);

--
-- Índices para tabela `loja`
--
ALTER TABLE `loja`
  ADD PRIMARY KEY (`id_loja`);

--
-- Índices para tabela `pix`
--
ALTER TABLE `pix`
  ADD PRIMARY KEY (`id_chave_pix`);

--
-- Índices para tabela `valor`
--
ALTER TABLE `valor`
  ADD PRIMARY KEY (`id_valor`);

--
-- Índices para tabela `venda`
--
ALTER TABLE `venda`
  ADD PRIMARY KEY (`id_venda`);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `cartao`
--
ALTER TABLE `cartao`
  ADD CONSTRAINT `cartao_ibfk_1` FOREIGN KEY (`idcartao`) REFERENCES `forma_pagamento` (`idforma_pagamento`);

--
-- Limitadores para a tabela `dinheiro`
--
ALTER TABLE `dinheiro`
  ADD CONSTRAINT `dinheiro_ibfk_1` FOREIGN KEY (`id_dinheiro`) REFERENCES `forma_pagamento` (`idforma_pagamento`);

--
-- Limitadores para a tabela `forma_pagamento`
--
ALTER TABLE `forma_pagamento`
  ADD CONSTRAINT `forma_pagamento_ibfk_1` FOREIGN KEY (`idforma_pagamento`) REFERENCES `valor` (`id_valor`);

--
-- Limitadores para a tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD CONSTRAINT `funcionario_ibfk_1` FOREIGN KEY (`id_funcionario`) REFERENCES `loja` (`id_loja`);

--
-- Limitadores para a tabela `ingresso`
--
ALTER TABLE `ingresso`
  ADD CONSTRAINT `ingresso_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `loja` (`id_loja`);

--
-- Limitadores para a tabela `loja`
--
ALTER TABLE `loja`
  ADD CONSTRAINT `loja_ibfk_1` FOREIGN KEY (`id_loja`) REFERENCES `jogador` (`id_jogador`);

--
-- Limitadores para a tabela `pix`
--
ALTER TABLE `pix`
  ADD CONSTRAINT `pix_ibfk_1` FOREIGN KEY (`id_chave_pix`) REFERENCES `forma_pagamento` (`idforma_pagamento`);

--
-- Limitadores para a tabela `valor`
--
ALTER TABLE `valor`
  ADD CONSTRAINT `valor_ibfk_1` FOREIGN KEY (`id_valor`) REFERENCES `venda` (`id_venda`);

--
-- Limitadores para a tabela `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`id_venda`) REFERENCES `loja` (`id_loja`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
